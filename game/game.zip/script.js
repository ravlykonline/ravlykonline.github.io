// --- 1. EventBus ---
// A simple publish-subscribe pattern to decouple game systems.
// E.g., Player collects an item -> Emits event -> ScoreSystem updates (Player doesn't need to know about ScoreSystem).
const EventBus = {
    listeners: {},
    on(event, callback) {
        if (!this.listeners[event]) this.listeners[event] = [];
        this.listeners[event].push(callback);
    },
    emit(event, data) {
        if (this.listeners[event]) this.listeners[event].forEach(cb => cb(data));
    }
};

// --- 2. Input System ---
// Centralized input handling. Converts physical inputs (keys, mouse) into game intents.
const Input = {
    keys: {},
    mouse: { x: 0, y: 0, isDown: false, intentTarget: null },

    // Clears the movement target (used when colliding or starting a dialog).
    clearTarget() {
        this.mouse.intentTarget = null;
    },
    init() {
        window.addEventListener('keydown', e => { this.keys[e.key] = true; this.clearTarget(); });
        window.addEventListener('keyup', e => { this.keys[e.key] = false; });
        window.addEventListener('mousedown', e => {
            if (e.button === 0) { this.mouse.isDown = true; this.mouse.x = e.clientX; this.mouse.y = e.clientY; }
        });
        window.addEventListener('mouseup', e => { if (e.button === 0) this.mouse.isDown = false; });
        window.addEventListener('mousemove', e => { this.mouse.x = e.clientX; this.mouse.y = e.clientY; });
    }
};

// --- 3. DOM References ---
// Caching DOM elements to prevent repetitive queries during the game loop.
const DOM = {
    gameArea: document.getElementById('game-area'),
    playerWrapper: document.getElementById('player-wrapper'),
    playerInner: document.getElementById('player-inner'),
    obstaclesContainer: document.getElementById('obstacles-container'),
    itemsContainer: document.getElementById('items-container'),
    npcsContainer: document.getElementById('npcs-container'),
    scoreDisplay: document.getElementById('score-display'),
    dialogLayer: document.getElementById('dialog-layer'),
    dialogTitle: document.getElementById('dialog-title'),
    dialogText: document.getElementById('dialog-text'),
    dialogBtn: document.getElementById('dialog-btn')
};

// --- 4. Core Configuration ---
const CONFIG = {
    playerRadius: 20,
    speed: 3,
    spurtDuration: 30, // Frames the snail is actively moving
    pauseDuration: 40, // Frames the snail is resting/contracting
    worldWidth: 4000,
    worldHeight: 4000,
    cameraThreshold: 250 // Distance to screen edge before camera pans
};

// --- 5. Data Layer ---
// Pre-defined static data for the level. Keeps data separate from logic.
const LevelData = {
    level1: {
        npcs: [
            {
                id: 'mouse_1',
                name: 'Мишка',
                type: 'mouse',
                x: 2500, y: 2000, w: 40, h: 40,
                interacted: false,
                completed: false,
                // Multiple puzzles for replayability. One will be chosen randomly per session.
                puzzles: [
                    { id: 'm1_p1', dialog: 'Привіт! Я Мишка. Завдання 1: Знайди де більше кружечків: ліворуч чи праворуч?' },
                    { id: 'm1_p2', dialog: 'Привіт! Я Мишка. Завдання 2: Де менше квадратиків?' },
                    { id: 'm1_p3', dialog: 'Привіт! Я Мишка. Завдання 3: Порівняй ці дві множини.' }
                ]
            },
            {
                id: 'beetle_1',
                name: 'Жук',
                type: 'beetle',
                x: 1800, y: 2200, w: 30, h: 30,
                interacted: false,
                completed: false,
                puzzles: [
                    { id: 'b1_p1', dialog: 'Я Жук. Завдання 1: Яка фігура наступна у послідовності?' },
                    { id: 'b1_p2', dialog: 'Я Жук. Завдання 2: Знайди зайвий елемент.' }
                ]
            }
        ]
    }
};

// --- 6. Scene Manager ---
// Manages active game states. Allows pushing a dialog/puzzle scene on top of the main game,
// freezing the game beneath it until the top scene is popped.
const SceneManager = {
    stack: [],
    get active() { return this.stack[this.stack.length - 1]; },
    push(scene) {
        if (this.active && this.active.pause) this.active.pause();
        this.stack.push(scene);
        if (scene.init) scene.init();
    },
    pop() {
        const scene = this.stack.pop();
        if (scene.destroy) scene.destroy();
        if (this.active && this.active.resume) this.active.resume();
    },
    update() { if (this.active && this.active.update) this.active.update(); },
    render() { if (this.active && this.active.render) this.active.render(); }
};

// --- 7. Scenes ---

// DialogScene: Renders the NPC interaction UI. Will later be expanded into a PuzzleScene.
class DialogScene {
    constructor(npcData) {
        this.npc = npcData;
        this.handleBind = this.handleNext.bind(this);
    }
    init() {
        Input.mouse.isDown = false; // Prevent accidental movement when exiting dialog
        DOM.dialogTitle.textContent = this.npc.name;
        // Render the randomly selected puzzle for this session
        DOM.dialogText.textContent = this.npc.activePuzzle.dialog;
        DOM.dialogLayer.style.display = 'flex';
        DOM.dialogBtn.addEventListener('click', this.handleBind);
    }
    handleNext() {
        this.npc.completed = true; // Mark as solved to prevent re-triggering
        document.querySelector(`.npc[data-id="${this.npc.id}"]`)?.classList.add('completed');
        SceneManager.pop(); // Return to GameScene
        EventBus.emit('puzzle:completed', { npcId: this.npc.id, stars: 1 });
    }
    destroy() {
        DOM.dialogLayer.style.display = 'none';
        DOM.dialogBtn.removeEventListener('click', this.handleBind);
    }
    update() { }
    render() { }
}

// GameScene: The main gameplay loop (movement, collisions, camera, item collection).
class GameScene {
    constructor() {
        this.state = {
            x: 2000, y: 2000, angle: 0,
            spurtPhase: 'idle', spurtTimer: 0,
            camera: { x: 0, y: 0 }, targetCamera: { x: 0, y: 0 }
        };
        this.obstacles = [];
        this.apples = [];

        // Deep copy LevelData and assign a random puzzle to each NPC for this session
        this.npcs = JSON.parse(JSON.stringify(LevelData.level1.npcs)).map(npc => {
            const randomPuzzleIndex = Math.floor(Math.random() * npc.puzzles.length);
            npc.activePuzzle = npc.puzzles[randomPuzzleIndex];
            return npc;
        });

        this.generateWorld();
    }

    // Procedurally generates obstacles and apples, ensuring no overlaps and keeping spawn area clear.
    generateWorld() {
        const obstacleTypes = ['rock', 'bush', 'twig'];
        for (let i = 0; i < 150; i++) {
            let placed = false, attempts = 0;
            while (!placed && attempts < 50) {
                const type = obstacleTypes[Math.floor(Math.random() * obstacleTypes.length)];
                const isHorizontal = Math.random() > 0.5;
                let w = type === 'twig' ? (isHorizontal ? Math.random() * 100 + 80 : 20) : Math.random() * 60 + 40;
                let h = type === 'twig' ? (isHorizontal ? 20 : Math.random() * 100 + 80) : w;
                const x = Math.random() * (CONFIG.worldWidth - w - 200) + 100;
                const y = Math.random() * (CONFIG.worldHeight - h - 200) + 100;

                // Check distance from player spawn (2000, 2000)
                if (Math.hypot((x + w / 2) - this.state.x, (y + h / 2) - this.state.y) < 200) { attempts++; continue; }

                // Check AABB collision with existing obstacles (+40px buffer)
                let overlap = this.obstacles.some(obs => x < obs.x + obs.w + 40 && x + w + 40 > obs.x && y < obs.y + obs.h + 40 && y + h + 40 > obs.y);
                if (!overlap) { this.obstacles.push({ x, y, w, h, type }); placed = true; }
                attempts++;
            }
        }

        for (let i = 0; i < 50; i++) {
            let placed = false, attempts = 0;
            while (!placed && attempts < 50) {
                const x = Math.random() * (CONFIG.worldWidth - 220) + 100, y = Math.random() * (CONFIG.worldHeight - 220) + 100;
                let overlap = this.obstacles.some(obs => x < obs.x + obs.w && x + 20 > obs.x && y < obs.y + obs.h && y + 20 > obs.y);
                if (!overlap) { this.apples.push({ id: i, x, y, w: 20, h: 20 }); placed = true; }
                attempts++;
            }
        }
    }

    init() {
        // Populate DOM with generated objects
        this.obstacles.forEach(obs => {
            const el = document.createElement('div');
            el.className = `obstacle ${obs.type}`;
            el.style.left = `${obs.x}px`; el.style.top = `${obs.y}px`; el.style.width = `${obs.w}px`; el.style.height = `${obs.h}px`;
            DOM.obstaclesContainer.appendChild(el);
        });
        this.apples.forEach(apple => {
            const el = document.createElement('div');
            el.className = 'apple'; el.id = `apple-${apple.id}`; el.style.left = `${apple.x}px`; el.style.top = `${apple.y}px`;
            DOM.itemsContainer.appendChild(el);
        });
        this.npcs.forEach(npc => {
            const el = document.createElement('div');
            el.className = `npc ${npc.type}`; el.style.left = `${npc.x}px`; el.style.top = `${npc.y}px`; el.style.width = `${npc.w}px`; el.style.height = `${npc.h}px`;
            el.dataset.id = npc.id;
            el.textContent = npc.type === 'beetle' ? 'Ж' : (npc.type === 'mouse' ? '🐭' : '');
            if (npc.completed) el.classList.add('completed');
            DOM.npcsContainer.appendChild(el);
        });

        // Initial camera centering
        this.state.targetCamera.x = Math.max(0, Math.min(this.state.x - window.innerWidth / 2, CONFIG.worldWidth - window.innerWidth));
        this.state.targetCamera.y = Math.max(0, Math.min(this.state.y - window.innerHeight / 2, CONFIG.worldHeight - window.innerHeight));
        this.state.camera.x = this.state.targetCamera.x; this.state.camera.y = this.state.targetCamera.y;
    }

    pause() { Input.clearTarget(); }
    resume() { Input.mouse.isDown = false; }

    update() {
        let intentDx = 0, intentDy = 0;

        // Item Collection (iterate backwards to safely splice during loop)
        for (let i = this.apples.length - 1; i >= 0; i--) {
            const apple = this.apples[i];
            if (Math.hypot(this.state.x - (apple.x + 10), this.state.y - (apple.y + 10)) < CONFIG.playerRadius + 10) {
                EventBus.emit('item:collected', { type: 'apple', value: 1 });
                document.getElementById(`apple-${apple.id}`)?.remove();
                this.apples.splice(i, 1);
            }
        }

        // NPC Proximity Triggers
        for (const npc of this.npcs) {
            const dist = Math.hypot(this.state.x - (npc.x + npc.w / 2), this.state.y - (npc.y + npc.h / 2));
            // Trigger if close, hasn't been interacted with yet, and puzzle isn't completed
            if (dist < 80 && !npc.interacted && !npc.completed) {
                npc.interacted = true;
                SceneManager.push(new DialogScene(npc));
            } else if (dist > 120) {
                npc.interacted = false; // Reset trigger threshold when player walks away
            }
        }

        // Input processing
        if (Input.mouse.isDown) Input.mouse.intentTarget = { x: Input.mouse.x + this.state.camera.x, y: Input.mouse.y + this.state.camera.y };
        if (Input.keys.w || Input.keys.ArrowUp) intentDy -= 1;
        if (Input.keys.s || Input.keys.ArrowDown) intentDy += 1;
        if (Input.keys.a || Input.keys.ArrowLeft) intentDx -= 1;
        if (Input.keys.d || Input.keys.ArrowRight) intentDx += 1;

        // Mouse movement logic overrides keyboard if active
        if (intentDx === 0 && intentDy === 0 && Input.mouse.intentTarget) {
            const tx = Input.mouse.intentTarget.x - this.state.x, ty = Input.mouse.intentTarget.y - this.state.y;
            if (Math.hypot(tx, ty) > CONFIG.speed) { intentDx = tx; intentDy = ty; } else { Input.clearTarget(); }
        }

        // Snail movement phases (spurt -> pause -> idle)
        if (this.state.spurtPhase === 'moving') {
            this.state.spurtTimer--;
            if (this.state.spurtTimer <= 0) {
                this.state.spurtPhase = 'pausing';
                this.state.spurtTimer = CONFIG.pauseDuration;
            }
        } else if (this.state.spurtPhase === 'pausing') {
            this.state.spurtTimer--;
            if (this.state.spurtTimer <= 0) this.state.spurtPhase = 'idle';
        }

        const hasIntent = intentDx !== 0 || intentDy !== 0;

        // Start a new spurt if intended and currently idle
        if (hasIntent && this.state.spurtPhase === 'idle') {
            this.state.spurtPhase = 'moving';
            this.state.spurtTimer = CONFIG.spurtDuration;
        }

        // Apply physical movement only during the 'moving' phase
        if (this.state.spurtPhase === 'moving' && hasIntent) {
            const length = Math.hypot(intentDx, intentDy);
            const dx = (intentDx / length) * CONFIG.speed, dy = (intentDy / length) * CONFIG.speed;

            if (this.resolveMovement(dx, dy)) {
                // Smooth rotation towards target vector
                let targetAngle = Math.atan2(dy, dx) * (180 / Math.PI);
                let diff = targetAngle - this.state.angle;
                // Prevent 360-degree spins across boundaries
                while (diff <= -180) diff += 360;
                while (diff > 180) diff -= 360;

                this.state.angle += diff;
                this.state.angle = ((this.state.angle % 360) + 360) % 360;
            } else {
                // Halt spurt early if colliding
                this.state.spurtPhase = 'idle';
            }
        }

        this.updateCamera();
    }

    // Checks X and Y axes independently to allow sliding along walls
    resolveMovement(dx, dy) {
        let moved = false;
        if (dx !== 0) {
            this.state.x += dx;
            if (this.isCollision(this.state.x, this.state.y)) { this.state.x -= dx; Input.clearTarget(); } else moved = true;
        }
        if (dy !== 0) {
            this.state.y += dy;
            if (this.isCollision(this.state.x, this.state.y)) { this.state.y -= dy; Input.clearTarget(); } else moved = true;
        }
        return moved;
    }

    // AABB (Axis-Aligned Bounding Box) vs Circle collision detection
    isCollision(px, py) {
        if (px < CONFIG.playerRadius || px > CONFIG.worldWidth - CONFIG.playerRadius || py < CONFIG.playerRadius || py > CONFIG.worldHeight - CONFIG.playerRadius) return true;
        return this.obstacles.some(obs => {
            let testX = px < obs.x ? obs.x : (px > obs.x + obs.w ? obs.x + obs.w : px);
            let testY = py < obs.y ? obs.y : (py > obs.y + obs.h ? obs.y + obs.h : py);
            return Math.hypot(px - testX, py - testY) <= CONFIG.playerRadius;
        });
    }

    // Calculates camera position with a deadzone (threshold) and linear interpolation (LERP)
    updateCamera() {
        const screenX = this.state.x - this.state.targetCamera.x, screenY = this.state.y - this.state.targetCamera.y;

        if (screenX < CONFIG.cameraThreshold) this.state.targetCamera.x -= (CONFIG.cameraThreshold - screenX);
        else if (screenX > window.innerWidth - CONFIG.cameraThreshold) this.state.targetCamera.x += (screenX - (window.innerWidth - CONFIG.cameraThreshold));

        if (screenY < CONFIG.cameraThreshold) this.state.targetCamera.y -= (CONFIG.cameraThreshold - screenY);
        else if (screenY > window.innerHeight - CONFIG.cameraThreshold) this.state.targetCamera.y += (screenY - (window.innerHeight - CONFIG.cameraThreshold));

        // Constrain camera to world bounds
        this.state.targetCamera.x = Math.max(0, Math.min(this.state.targetCamera.x, CONFIG.worldWidth - window.innerWidth));
        this.state.targetCamera.y = Math.max(0, Math.min(this.state.targetCamera.y, CONFIG.worldHeight - window.innerHeight));

        // Apply LERP for smooth panning
        this.state.camera.x += (this.state.targetCamera.x - this.state.camera.x) * 0.05;
        this.state.camera.y += (this.state.targetCamera.y - this.state.camera.y) * 0.05;
    }

    // Applies calculated state to DOM elements
    render() {
        DOM.gameArea.style.transform = `translate(${-this.state.camera.x}px, ${-this.state.camera.y}px)`;
        DOM.playerWrapper.style.left = `${this.state.x}px`; DOM.playerWrapper.style.top = `${this.state.y}px`;
        DOM.playerInner.style.transform = `rotate(${this.state.angle}deg)`;
        DOM.playerInner.className = this.state.spurtPhase;
    }
}

// --- 8. Score System ---
// Listens to EventBus and updates UI accordingly. Independent from GameScene logic.
const ScoreSystem = {
    apples: 0, stars: 0,
    init() {
        EventBus.on('item:collected', data => { if (data.type === 'apple') this.apples += data.value; this.updateUI(); });
        EventBus.on('puzzle:completed', data => { this.stars += data.stars; this.updateUI(); });
    },
    updateUI() { DOM.scoreDisplay.textContent = `Яблука: ${this.apples} | Зірочки: ${this.stars}`; }
};

// --- 9. Boot ---
function gameLoop() {
    SceneManager.update();
    SceneManager.render();
    requestAnimationFrame(gameLoop);
}

// Initialize systems and start loop
Input.init();
ScoreSystem.init();
SceneManager.push(new GameScene());
requestAnimationFrame(gameLoop);
